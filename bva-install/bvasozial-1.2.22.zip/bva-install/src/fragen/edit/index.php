<?php
	header("Location: ../");
?>