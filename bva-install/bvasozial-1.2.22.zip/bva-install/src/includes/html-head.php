<meta charset="utf-8">
<meta name="description" content="">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">

<title>BvAsozial &gt; Admin &gt; Dashboard</title>

<meta name="mobile-web-app-capable" content="yes">

<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta name="apple-mobile-web-app-title" content="BvAsozial">
<meta name="msapplication-TileColor" content="#252830">

<link rel="shortcut icon" href="/img/favicon.png">

<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:regular,bold,italic,thin,light,bolditalic,black,medium&amp;lang=en">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

<link rel="stylesheet" href="/css/bvasozial.mdl.src.css">
<link rel="stylesheet" href="/css/sidewide.css">
<link rel="stylesheet" href="css/admin.css">

<script src="/js/jquery-2.1.4.min.js"></script>
