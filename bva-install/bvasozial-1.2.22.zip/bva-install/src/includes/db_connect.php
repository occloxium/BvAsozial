<?php

	$mysqli = new mysqli(HOST, USER, PASSWORD, DATABASE);
?>
