<?php 
	define('HOST', 'localhost');
	define('USER', 'bvasozialadmin');
	define('PASSWORD', 'S2Xb5oDe&*xC9j#eYI&f5kAHztxuHJZL');
	define('DATABASE', 'bvasozial');
	$mysqli = new mysqli(HOST, USER, PASSWORD, DATABASE);
?>