<?php
	define('SECURE', false);
	define('INDEV', true);
?>