<?php
	include_once '../../includes/db_connect.php';
	include_once '../../includes/functions.php';
	secure_session_start();

	if(isset($_POST['uid'], $_POST['password'])){
		if(login_check($mysqli)){
			$h_pw = sha1($_POST['password']);
			if($stmt = $mysqli->prepare('UPDATE login SET password = ? WHERE uid = ?')){
				$stmt->bind_param('ss', $h_pw, $_POST['uid']);
				$stmt->execute();
				if($stmt->errno == 00000){
					echo success(["html" => "<p>Das neue Passwort wurde gesetzt<br>Der Benutzer {$_POST['uid']} hat nun das Passwort: <br>{$_POST['password']}</p><a href=\"../\">Zurück</a>"]);	
				} else {
					echo error('internalError', 500, 'Could not execute request');
				}
			} else {
				echo error('internalError', 500, 'Could not prepare statement');
			}
		} else {
			echo error('clientError', 403, 'Forbidden');
		}
	} else {
		echo error('clientError', 400, 'Bad Request');
	}
?>